import morpheus_mcpi

morpheus_mcpi.start()
